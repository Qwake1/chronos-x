Hello! Welcome to Chronos X.

This is a level 8 executor that allows you to execute lua scripts

If you need any help, message us here:

Discord Account: Nam3#0804
Discord Server: https://discord.gg/dk6mhwnWST

Q/A

(Who made this executor)
This was developed by Nam3

(Who is Nam3?)

Nam3 is an up and coming executor developer

(Is Chronos X a virus?)
No, it is a false positive. Every executor has something called an API (Application Programming Interface) this is used to inject into the roblox instance and execute lua scripts.

This API is tilted as a (GameHack) from most antiviruses, but is not a game hack as it is scripting tool designed for lua developers.

It is also titled as a Trojan (Trojan Horse: a program designed to breach the security of a computer system while ostensibly performing some innocuous function) This is not true as we don't require administrator permissions that are required to do so.

(I'm having trouble)
Contact us via joinging our discord server (https://discord.gg/dk6mhwnWST)